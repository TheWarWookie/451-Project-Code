# ReHILAE
PHYS369: Astrophysics Group Project

MAKE SURE YOU CREATE A NEW BRANCH BEFORE MAKING ANY CHANGES

Branch Guide:

1. Download master file either via GitHub Desktop or as a zip file
2. Once any changes have been made, upload files into a new, suitably named branch
3. When you think the branch is ready to be merged to the master, submit a pull request
4. Make any changes required before merging
5. Once the merge is successful delete the branch
